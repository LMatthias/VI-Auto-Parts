﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ViAutoParts.Models;

namespace ViAutoParts.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public IActionResult SignUp()
        {
            Customer customer = new Customer();
            return View(customer);
        }

        [HttpPost]
        public IActionResult SignUp(Customer customer)
        {
            if(string.IsNullOrEmpty(customer.Password))
            {
                ViewBag.Message = "Please enter a password.";
                return View(customer);
            } else
            {
                try
                {
                    using (ViAutoPartsContext context = new ViAutoPartsContext())
                    {
                        context.Customer.Add(customer);
                        context.SaveChanges();
                    }
                }
                catch (Exception ex)
                {
                    var error = ex.Message;
                }

                return View("SignUpResults", customer);
            }          
        }

        [HttpGet]
        public IActionResult SignIn()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SignIn(string email, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ViewBag.Message = "Please fill in all that is required.";
                return View();
            }

            try
            {
                using(ViAutoPartsContext context = new ViAutoPartsContext())
                {
                    var customer = context.Customer.Where(c => c.EmailAddress == email && c.Password == password).SingleOrDefault();

                    if(customer == null)
                    {
                        ViewBag.Message = "Email or password is incorrect.";
                        return View();
                    }

                    Account.Id = customer.CustomerId;
                    Account.Name = customer.FirstName;
                    Account.SignInStatus = true;
                    return RedirectToAction("Welcome", "Home");
                }
            }
            catch (Exception ex)
            {
                var error = new ErrorViewModel();
                error.RequestId = ex.Message;
                return View("Error", error);
            }
        }

        public IActionResult SignOut()
        {
            Account.SignInStatus = false;
            return RedirectToAction("Welcome", "Home");
        }
    }
}