﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ViAutoParts.Models;

namespace ViAutoParts.Controllers
{
    public class CatalogController : Controller
    {
        public IActionResult Catalog()
        {
            
            using(ViAutoPartsContext context = new ViAutoPartsContext())
            {
                var parts = context.Part.ToList();
                return View(parts);
            }
            
        }

        public IActionResult PartSearch(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return RedirectToAction("Welcome","Home");
            }
            else
            {
                ViewBag.Search = input;
                using (ViAutoPartsContext context = new ViAutoPartsContext())
                {

                    var parts = context.Part
                                       .Where(s => s.PartName.Contains(input) || s.PartName.Contains(input.ToLower()))
                                       .ToList();

                    return View(parts);
                }

            }
        }
        
    }
}