﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ViAutoParts.Models
{
    public partial class ViAutoPartsContext : DbContext
    {
        public ViAutoPartsContext()
        {
        }

        public ViAutoPartsContext(DbContextOptions<ViAutoPartsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Administrator> Administrator { get; set; }
        public virtual DbSet<Customer> Customer { get; set; }
        public virtual DbSet<Manufacturer> Manufacturer { get; set; }
        public virtual DbSet<Order> Order { get; set; }
        public virtual DbSet<Part> Part { get; set; }
        public virtual DbSet<VehicleType> VehicleType { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("server=localhost; port=3306; uid=root; pwd=smith017; database=mydb;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Administrator>(entity =>
            {
                entity.HasKey(e => e.AdminId);

                entity.ToTable("administrator");

                entity.Property(e => e.AdminId)
                    .HasColumnName("admin_id")
                    .HasColumnType("int(10)");

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasColumnName("email_address")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnName("first_name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnName("last_name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasColumnType("varchar(45)");
            });

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.ToTable("customer");

                entity.Property(e => e.CustomerId)
                    .HasColumnName("customer_id")
                    .HasColumnType("int(10)");

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasColumnName("city")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasColumnName("email_address")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnName("first_name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasColumnName("last_name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.MailAddress)
                    .IsRequired()
                    .HasColumnName("mail_address")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.PhoneNumber)
                    .IsRequired()
                    .HasColumnName("phone_number")
                    .HasColumnType("varchar(15)");

                entity.Property(e => e.State)
                    .IsRequired()
                    .HasColumnName("state")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Zipcode)
                    .HasColumnName("zipcode")
                    .HasColumnType("int(11)");
            });

            modelBuilder.Entity<Manufacturer>(entity =>
            {
                entity.ToTable("manufacturer");

                entity.Property(e => e.ManufacturerId)
                    .HasColumnName("manufacturer_id")
                    .HasColumnType("int(10)");

                entity.Property(e => e.City)
                    .HasColumnName("city")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.EmailAddress)
                    .HasColumnName("email_address")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.ManufacturerName)
                    .IsRequired()
                    .HasColumnName("manufacturer_name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.PhoneNumber)
                    .HasColumnName("phone_number")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.State)
                    .HasColumnName("state")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.StreetAddress)
                    .HasColumnName("street_address")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.Zipcode)
                    .HasColumnName("zipcode")
                    .HasColumnType("int(11)");
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.ToTable("order");

                entity.Property(e => e.OrderId)
                    .HasColumnName("order_id")
                    .HasColumnType("int(10)");

                entity.Property(e => e.AdminId)
                    .HasColumnName("admin_id")
                    .HasColumnType("int(10)");

                entity.Property(e => e.OrderQuantity)
                    .HasColumnName("order_quantity")
                    .HasColumnType("int(10)");

                entity.Property(e => e.PartId)
                    .HasColumnName("part_id")
                    .HasColumnType("int(10)");
            });

            modelBuilder.Entity<Part>(entity =>
            {
                entity.ToTable("part");

                entity.Property(e => e.PartId)
                    .HasColumnName("part_id")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.InventoryQuantity)
                    .HasColumnName("inventory_quantity")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Keywords)
                    .IsRequired()
                    .HasColumnName("keywords")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.LastRestocked)
                    .HasColumnName("last_restocked")
                    .HasColumnType("datetime");

                entity.Property(e => e.ManufacturerId)
                    .HasColumnName("manufacturer_id")
                    .HasColumnType("int(10)");

                entity.Property(e => e.PartName)
                    .IsRequired()
                    .HasColumnName("part_name")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.PartPrice)
                    .HasColumnName("part_price")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.PartYear)
                    .HasColumnName("part_year")
                    .HasColumnType("varchar(45)");
            });

            modelBuilder.Entity<VehicleType>(entity =>
            {
                entity.HasKey(e => e.PartId);

                entity.ToTable("vehicle_type");

                entity.Property(e => e.PartId)
                    .HasColumnName("part_id")
                    .HasColumnType("int(10)");

                entity.Property(e => e.VehicleMake)
                    .IsRequired()
                    .HasColumnName("vehicle_make")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.VehicleModel)
                    .IsRequired()
                    .HasColumnName("vehicle_model")
                    .HasColumnType("varchar(45)");

                entity.Property(e => e.VehicleYear)
                    .IsRequired()
                    .HasColumnName("vehicle_year")
                    .HasColumnType("varchar(45)");
            });
        }
    }
}
