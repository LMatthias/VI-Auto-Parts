﻿using System;
using System.Collections.Generic;

namespace ViAutoParts.Models
{
    public partial class VehicleType
    {
        public int PartId { get; set; }
        public string VehicleYear { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModel { get; set; }
    }
}
