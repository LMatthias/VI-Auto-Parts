﻿using System;
using System.Collections.Generic;

namespace ViAutoParts.Models
{
    public partial class Part
    {
        public string PartId { get; set; }
        public string PartName { get; set; }
        public decimal? PartPrice { get; set; }
        public int? PartYear { get; set; }
        public int ManufacturerId { get; set; }
        public string Keywords { get; set; }
        public int InventoryQuantity { get; set; }
        public DateTime? LastRestocked { get; set; }
    }
}
