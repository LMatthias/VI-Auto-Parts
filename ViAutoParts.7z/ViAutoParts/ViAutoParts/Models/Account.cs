﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ViAutoParts.Models
{
    public class Account
    {
        public static int Id { get; set; }
        public static string Name { get; set; }
        public static bool SignInStatus { get; set; }
    }
}
