﻿using System;
using System.Collections.Generic;

namespace ViAutoParts.Models
{
    public partial class Order
    {
        public int OrderId { get; set; }
        public int PartId { get; set; }
        public int OrderQuantity { get; set; }
        public int AdminId { get; set; }
    }
}
